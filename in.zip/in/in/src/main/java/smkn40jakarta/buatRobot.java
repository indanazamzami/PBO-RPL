package smkn40jakarta;

public class buatRobot {
    public static void main(String[] args) {  
        Robot woody = new Robot(true, "Woody");
        woody.siapkanBadan();
        woody.pasangKepala();
        woody.pasangRambut(1);
        woody.pasangMata();
        woody.pasangMata();
        woody.pasangTangan();
        woody.pasangTangan();
        woody.pasangKaki();
        woody.pasangKaki();        
        woody.pasangCelanaPanjang();
        woody.pasangKemeja();
        woody.cetak();
        
        Robot barbie = new Robot(false, "Barbie");
    }
}

class Robot{
    String nama;
    boolean jenisKelamin; 
    boolean badan;
    boolean kepala;
    int rambut;
    int mata;
    boolean hidung;
    boolean mulut;
    int kuping;
    int tangan;
    int kaki;
    boolean kemeja;
    boolean celanaPanjang;
    boolean gaun;
    boolean jilbab;
    boolean topi;
    boolean mesin;
    boolean batere;
    boolean statusMesin;
    int statusBadan;
    int arah; 
    int statusGerak;
    
    Robot(boolean jk, String nm){
        this.jenisKelamin=jk;
        this.nama = nm;
    }
    
    void cetak(){
        System.out.println("nama = " + nama);
        System.out.println("jenisKelamin = " + jenisKelamin);
        System.out.println("badan = " + badan);
        System.out.println("kepala = " + kepala);
        System.out.println("rambut = " + rambut);
        System.out.println("mata = " + mata);
        System.out.println("hidung = " +  hidung);
        System.out.println("mulut = " +  mulut);
        System.out.println("kuping = " +  kuping);
        System.out.println("tangan = " +  tangan);
        System.out.println("kaki = " +  kaki);
        System.out.println("tubuh Lengkap = " +  tubuhLengkap());
        System.out.println("kemeja = " +  kemeja);
        System.out.println("celana panjang = " +  celanaPanjang);
        System.out.println("gaun = " +  gaun);
        System.out.println("topi = " +  topi);
        System.out.println("jilbab = " +  jilbab);
        
    }
    void siapkanBadan(){
        badan = true;
    }
    void pasangKepala(){
        if(badan) kepala=true;
    }
    void pasangRambut(int jenisRambut){
        if(kepala) rambut=jenisRambut;
    }
    
    void pasangMata(){
        if(mata<2)mata++;
    }
    void pasangTangan(){
        if(tangan<2)tangan++;
    }
    void pasangKaki(){
        if(kaki<2)kaki++;
    }    
    
    boolean tubuhLengkap(){
        return badan &&
               kepala  &&
               mata==2 &&
               hidung &&
               mulut &&
               kuping==2 &&
               tangan==2 &&
               kaki==2; 
    }
    void pasangKemeja(){
        if(tubuhLengkap()){
            kemeja=true;
            gaun=false;
        }
    }
    void pasangCelanaPanjang(){
        celanaPanjang=true;
        gaun=false;
    }    
    void pasangGaun(){
        if(jenisKelamin==false){
            kemeja=false;
            celanaPanjang=false;
            gaun=true;
        }
    }
    
    void pasangTopi(){
        topi=true;
    }
    
    void pasangJilbab(){
         if(jenisKelamin==false){
            jilbab=true;
         }
    }    
    
    /*
    boolean berpakaian();
    */
    

    void pasangMesin(){
        if(tubuhLengkap()) mesin=true;
    }
    
    void pasangBatere(){
        if(mesin) batere=true;
    }
    
    void nyalakan(){
        if(batere==true) statusMesin=true;
    }
    void matikan(){
        if(batere==true) statusMesin=false;
    }    
    
    void posisiBadan(int pos){
        statusBadan=pos;
    }
    
    void diam(){
        if(statusBadan==1 && statusMesin){
            statusGerak=1;
        }
    }

    void jalan(){
        if(statusBadan==1 && statusMesin){
            statusGerak=2;
        }
    }

    void lari(){
        if(statusBadan==1 && statusMesin){
            statusGerak=3;
        }
    }    
    
    void belokKanan(){
        if(statusBadan==1 && statusMesin){
            arah++;
            arah=arah%4;
        }        
    }
    
    void belokKiri(){
        if(statusBadan==1 && statusMesin){
            arah--;
            if(arah==-1)arah=3;
        }        
    }
}