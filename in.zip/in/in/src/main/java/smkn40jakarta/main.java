package smkn40jakarta;

public class main {
    public static void main(String[] args) {
        hewan Kucing = new hewan("Kucing");
        hewan Panda = new hewan("Panda");
        Kucing.beratHewan(5);
        Kucing.jumlahKakiHewan(4);
        Kucing.cetakHewan();
        Panda.beratHewan(70);
        Panda.jumlahKakiHewan(2);
        Panda.cetakHewan();
         } 
 }