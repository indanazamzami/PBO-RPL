package smkn40jakarta;

public class nilaiBalik {
public static void main(String[] args) {
    double s = 12;
    double hasil = hitungLuas(s); 
    System.out.println("Hasilnya adalah = " + hasil);
    }
static double luasPersegi(double sisi){
    return sisi * sisi;
    }
    static double hitungLuas(double sisi){
        return 6 * luasPersegi(sisi);
    }
}